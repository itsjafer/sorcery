#ifndef TYPE_H
#define TYPE_H

enum class Type {
    Minion,
    Spell,
    Enchantment,
    AddEnchantment,
    Ritual,
    ActivatedAbility,
    TriggeredAbility
};

#endif
