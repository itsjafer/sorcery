#ifndef STATE_H
#define STATE_H

enum class State {
    printBoard,
    printMinion,
    printHelp,
    printHand
};

#endif
