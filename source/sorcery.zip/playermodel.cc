#include "playermodel.h"

using namespace std;

PlayerModel::PlayerModel(std::string name, int playerNumber) : name(name), playerNumber(playerNumber) {}

PlayerModel::~PlayerModel() {
  
}
